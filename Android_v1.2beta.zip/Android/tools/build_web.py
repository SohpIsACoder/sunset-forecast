#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
火烧云预报 v1.2 —— 网页端构建工具

把单文件 index.html 拆分为「结构 + CSS」的 index.html 与独立业务脚本，
再用 terser 对业务脚本做混淆压缩。

  split   单文件index.html  输出目录     一次性拆分：生成 app-raw.js（未混淆备份）与 index.html
  minify  输出目录                       用 terser 把 app-raw.js 压缩混淆为 app.js

混淆策略（与用户要求一致）：
  · 开启变量名 / 函数名混淆（含顶层作用域）
  · 字符串字面量编码（非 ASCII 全部转义为 \\uXXXX）
  · 删除注释，仅保留 /*! 版权著作权注释头
  · 不做死循环 debugger、F12 检测等无效防护
  · HTML 内联 onclick 引用的函数名加入保留名单，避免混淆后调用失效
"""

import os
import re
import sys
import json
import glob
import subprocess

# HTML 内联事件处理器 / JS 内部动态拼接字符串引用的函数名，混淆时必须保留原名
RESERVED = [
    "handleCitySearch",     # HTML: onclick="handleCitySearch()" 与定位模块复用
    "setEventFilter",       # HTML: onclick="setEventFilter('all')"
    "setCanvasMode",        # HTML: onclick="setCanvasMode('sky')"
    "quickSelectCity",      # app.js 内动态拼接: onclick="quickSelectCity('...')"
    "selectSlot",           # app.js 内动态拼接: onclick="selectSlot('...')"
    "replayHistoryItem",    # app.js 内动态拼接: onclick="replayHistoryItem(id)"
    "__applyThemeFromSystem",  # 安卓外壳 evaluateJavascript 直接按名调用
]

LICENSE_HEADER = """/*!
 * 火烧云预报系统 · 前端业务脚本
 * Copyright (c) 2026 Sohp. All rights reserved.
 *
 * 本文件为著作权作品，受法律保护；未经书面许可，禁止复制、传播或二次分发。
 */
"""

SCRIPT_RE = re.compile(r"<script\b(?![^>]*\bsrc=)[^>]*>(.*?)</script>", re.S | re.I)
STYLE_RE = re.compile(r"<style\b[^>]*>.*?</style>", re.S | re.I)
COMMENT_RE = re.compile(r"<!--.*?-->", re.S)


# --------------------------------------------------------------------------- #
#  拆分
# --------------------------------------------------------------------------- #
def pick_block(blocks, marker):
    for b in blocks:
        if marker in b:
            return b
    raise SystemExit("[split] 未找到包含标记 %r 的脚本块" % marker)


def restructure_theme(block):
    """主题控制器原本在解析期直接绑定 DOM；app.js 前置于 <head>，
    DOM 尚未构建，故把绑定动作收进 bindUi() 并延迟到 DOMContentLoaded 执行。
    主题预置与应用逻辑保持不变，行为与拆分前完全一致。"""
    b = block
    a1 = '      var gear = document.getElementById("themeGear");'
    if a1 not in b:
        raise SystemExit("[split] 主题控制器锚点 1 未命中")
    b = b.replace(
        a1,
        '      function bindUi() {\n'
        '        var gear = document.getElementById("themeGear");',
        1,
    )

    a2 = "        });\n      }\n\n      // 系统深浅色变化时自动跟随"
    if a2 not in b:
        raise SystemExit("[split] 主题控制器锚点 2 未命中")
    b = b.replace(
        a2,
        "        });\n      }\n      }\n\n      // 系统深浅色变化时自动跟随",
        1,
    )

    a3 = "      apply(storedMode(), false);\n    })();"
    if a3 not in b:
        raise SystemExit("[split] 主题控制器锚点 3 未命中")
    b = b.replace(
        a3,
        "      apply(storedMode(), false);\n"
        '      if (document.readyState === "loading") '
        'window.addEventListener("DOMContentLoaded", bindUi);\n'
        "      else bindUi();\n    })();",
        1,
    )
    return b


def rewrite_html(html):
    """删除全部内联脚本（首个位置替换为外链 app.js），删除注释并做安全空白压缩。
    <style> 块原样保留，CSS 变量与布局不受影响；单个换行保留，避免改变行内元素间距。"""
    stashed = []

    def stash(m):
        stashed.append(m.group(0))
        return "\x00STYLE%d\x00" % (len(stashed) - 1)

    html = STYLE_RE.sub(stash, html)

    first = {"done": False}

    def repl_script(m):
        if first["done"]:
            return ""
        first["done"] = True
        return '<script src="app.js"></script>'

    html = SCRIPT_RE.sub(repl_script, html)
    html = COMMENT_RE.sub("", html)

    # 删除行尾空白 → 删除行首缩进 → 连续空行合并为单个换行
    html = re.sub(r"[ \t]+(?=\r?\n)", "", html)
    html = re.sub(r"(?m)^[ \t]+", "", html)
    html = re.sub(r"(\r?\n)[ \t]*(\r?\n)+", r"\n", html)

    for i, s in enumerate(stashed):
        html = html.replace("\x00STYLE%d\x00" % i, s)
    return html


def do_split(src, out_dir):
    with open(src, encoding="utf-8") as f:
        html = f.read()

    blocks = SCRIPT_RE.findall(html)
    if len(blocks) < 5:
        raise SystemExit("[split] 预期至少 5 个内联脚本块，实际 %d 个" % len(blocks))

    preset = pick_block(blocks, "主题预置")
    main = pick_block(blocks, "GRADES")
    theme = restructure_theme(pick_block(blocks, "themeGear"))
    anti_copy = pick_block(blocks, "selectstart")
    geoloc = pick_block(blocks, "sunset-auto-locate")

    app_raw = (
        LICENSE_HEADER
        + "\n"
        + preset.strip()
        + "\n\n"
        + main.strip()
        + "\n\n"
        + theme.strip()
        + "\n\n"
        + anti_copy.strip()
        + "\n\n"
        + geoloc.strip()
        + "\n"
    )

    os.makedirs(out_dir, exist_ok=True)
    raw_path = os.path.join(out_dir, "app-raw.js")
    with open(raw_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(app_raw)

    index_path = os.path.join(out_dir, "index.html")
    with open(index_path, "w", encoding="utf-8", newline="\n") as f:
        f.write(rewrite_html(html))

    print("[split] app-raw.js  : %d 字节" % os.path.getsize(raw_path))
    print("[split] index.html  : %d 字节" % os.path.getsize(index_path))
    return raw_path, index_path


# --------------------------------------------------------------------------- #
#  混淆压缩
# --------------------------------------------------------------------------- #
def find_toolchain():
    """向上逐级查找 .toolchain 目录（容纳便携版 Node.js 与 terser）。"""
    probe = os.path.dirname(os.path.dirname(os.path.abspath(__file__)))
    for _ in range(4):
        cand = os.path.join(probe, ".toolchain")
        if os.path.isdir(cand):
            return cand
        parent = os.path.dirname(probe)
        if parent == probe:
            break
        probe = parent
    raise SystemExit("[minify] 未找到 .toolchain 目录（便携版 Node.js / terser 应存放在此）")


def find_node(toolchain):
    hits = glob.glob(os.path.join(toolchain, "node", "**", "node.exe"), recursive=True)
    if not hits:
        raise SystemExit("[minify] 未找到 node.exe，请先下载便携版 Node.js 到 .toolchain/node/")
    return hits[0]


def do_minify(out_dir, toolchain=None, node_exe=None):
    toolchain = toolchain or find_toolchain()
    node_exe = node_exe or find_node(toolchain)

    terser_modules = os.path.join(toolchain, "terser", "node_modules")
    if not os.path.isdir(os.path.join(terser_modules, "terser")):
        raise SystemExit("[minify] 未找到 terser，请先执行：npm install --prefix %s terser" % os.path.join(toolchain, "terser"))

    runner = os.path.join(os.path.dirname(os.path.abspath(__file__)), "terser-run.js")
    config = {
        "ecma": 2020,
        "compress": {
            "passes": 2,
            "drop_debugger": True,
            "drop_console": False,
        },
        "mangle": {
            "toplevel": True,
            "reserved": RESERVED,
        },
        "format": {
            "comments": "/^!/",      # 仅保留版权著作权注释头
            "ascii_only": True,      # 字符串字面量编码：非 ASCII 转义为 \uXXXX
            "ecma": 2020,
        },
    }

    raw_path = os.path.join(out_dir, "app-raw.js")
    out_path = os.path.join(out_dir, "app.js")
    cfg_path = os.path.join(out_dir, ".terser.config.json")
    with open(cfg_path, "w", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False)

    env = dict(os.environ)
    env["NODE_PATH"] = terser_modules
    cmd = [node_exe, runner, raw_path, out_path, cfg_path]
    proc = subprocess.run(cmd, env=env, capture_output=True, text=True)
    if proc.returncode != 0:
        sys.stderr.write(proc.stdout + "\n" + proc.stderr + "\n")
        raise SystemExit("[minify] terser 执行失败")

    os.remove(cfg_path)
    print("[minify] app.js      : %d 字节（原始 %d 字节）" % (
        os.path.getsize(out_path), os.path.getsize(raw_path)))
    return out_path


def main(argv):
    if len(argv) < 2:
        raise SystemExit(__doc__)
    mode = argv[1]
    if mode == "split":
        if len(argv) < 4:
            raise SystemExit("用法: build_web.py split <单文件index.html> <输出目录>")
        do_split(argv[2], argv[3])
    elif mode == "minify":
        if len(argv) < 3:
            raise SystemExit("用法: build_web.py minify <输出目录> [--node <node.exe>] [--toolchain <目录>]")
        kw = {}
        if "--node" in argv:
            kw["node_exe"] = argv[argv.index("--node") + 1]
        if "--toolchain" in argv:
            kw["toolchain"] = argv[argv.index("--toolchain") + 1]
        do_minify(argv[2], **kw)
    else:
        raise SystemExit("未知模式: %s" % mode)


if __name__ == "__main__":
    main(sys.argv)
