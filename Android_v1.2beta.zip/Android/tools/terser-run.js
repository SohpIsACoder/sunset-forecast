/*
 * terser 驱动：读取输入脚本与 JSON 配置，输出混淆压缩后的脚本。
 * 用法： node terser-run.js <输入.js> <输出.js> <配置.json>
 */
"use strict";

const fs = require("fs");
const { minify } = require("terser");

const [input, output, cfgPath] = process.argv.slice(2);
if (!input || !output || !cfgPath) {
    console.error("usage: node terser-run.js <input> <output> <config.json>");
    process.exit(2);
}

const options = JSON.parse(fs.readFileSync(cfgPath, "utf8"));
const source = fs.readFileSync(input, "utf8");

minify(source, options)
    .then((result) => {
        if (result.error) throw result.error;
        fs.writeFileSync(output, result.code, "utf8");
        console.log("terser ok -> " + output);
    })
    .catch((err) => {
        console.error(String(err && err.stack ? err.stack : err));
        process.exit(1);
    });
