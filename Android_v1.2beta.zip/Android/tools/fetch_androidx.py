#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Fetch the full transitive dependency closure of androidx.work:work-runtime:2.7.0
into Android/libs/ using ONLY the Python standard library.

Produced layout:
  Android/libs/m2-cache/<group/as/path>/<artifact>/<version>/<artifact>-<version>.pom|.aar|.jar
  Android/libs/jars/<artifact>-<version>.jar     (classes.jar extracted from AAR, or plain jar)
  Android/libs/aar/<artifact>-<version>/{res/**, AndroidManifest.xml, proguard.txt, R.txt}
  Android/libs/deps.json

Idempotent: existing non-empty files are never re-downloaded, so the cache can be
reused offline later.

Usage: python tools/fetch_androidx.py
"""

import json
import os
import re
import shutil
import sys
import time
import urllib.error
import urllib.request
import xml.etree.ElementTree as ET
import zipfile

REPOS = [
    "https://maven.aliyun.com/repository/google",
    "https://maven.aliyun.com/repository/public",
    "https://repo1.maven.org/maven2",
]

ROOT_GAV = ("androidx.work", "work-runtime", "2.7.0")

HERE = os.path.dirname(os.path.abspath(__file__))
BASE = os.path.dirname(HERE)                 # .../Android
LIBS = os.path.join(BASE, "libs")
M2 = os.path.join(LIBS, "m2-cache")
JARS = os.path.join(LIBS, "jars")
AARS = os.path.join(LIBS, "aar")
DEPS_JSON = os.path.join(LIBS, "deps.json")

# scopes that must NOT be pulled into the runtime closure
SKIP_SCOPES = {"test", "provided", "system", "import"}

# --------------------------------------------------------------------------
# small helpers
# --------------------------------------------------------------------------

def log(msg=""):
    print(msg, flush=True)


def local(tag):
    return tag.split("}", 1)[1] if "}" in tag else tag


def child(el, name):
    if el is None:
        return None
    for c in el:
        if local(c.tag) == name:
            return c
    return None


def text_of(el, name):
    c = child(el, name)
    if c is None or c.text is None:
        return None
    t = c.text.strip()
    return t or None


def rel_path(group, artifact, version, filename):
    return "%s/%s/%s/%s" % (group.replace(".", "/"), artifact, version, filename)


def http_get(url, tries=2):
    last = None
    for _ in range(tries):
        try:
            req = urllib.request.Request(url, headers={"User-Agent": "fetch-androidx/1.0"})
            with urllib.request.urlopen(req, timeout=45) as r:
                return r.read()
        except Exception as e:          # noqa: BLE001 - network failures are expected
            last = e
    raise last


def cached_download(relpath):
    """Download relpath (slash-separated) into M2. Returns (path, repo) or (None, None)."""
    dest = os.path.join(M2, relpath.replace("/", os.sep))
    if os.path.exists(dest) and os.path.getsize(dest) > 0:
        return dest, "cache"
    os.makedirs(os.path.dirname(dest), exist_ok=True)
    for repo in REPOS:
        url = repo + "/" + relpath
        try:
            data = http_get(url)
        except Exception:               # noqa: BLE001
            continue
        if not data:
            continue
        tmp = dest + ".part"
        with open(tmp, "wb") as f:
            f.write(data)
        os.replace(tmp, dest)
        return dest, repo
    return None, None


# --------------------------------------------------------------------------
# POM model
# --------------------------------------------------------------------------

def fetch_pom(group, artifact, version):
    rel = rel_path(group, artifact, version, "%s-%s.pom" % (artifact, version))
    path, repo = cached_download(rel)
    if path is None:
        return None, None, None
    try:
        root = ET.parse(path).getroot()
    except Exception as e:              # noqa: BLE001
        return None, repo, "PARSE_ERROR: %s" % e
    return root, repo, path


def load_pom_chain(group, artifact, version):
    """Return (roots, repo, err). roots[0] is the artifact itself, then its parents."""
    roots = []
    repo_used = None
    g, a, v = group, artifact, version
    for _ in range(10):
        root, repo, path = fetch_pom(g, a, v)
        if root is None:
            if not roots:
                return [], None, (path or "not found")
            break
        if repo_used is None:
            repo_used = repo
        roots.append(root)
        par = child(root, "parent")
        if par is None:
            break
        pg, pa, pv = text_of(par, "groupId"), text_of(par, "artifactId"), text_of(par, "version")
        if not (pg and pa and pv):
            break
        g, a, v = pg, pa, pv
    return roots, repo_used, None


def collect_props(roots):
    d = {}
    for root in reversed(roots):        # parents first, child overrides
        props = child(root, "properties")
        if props is None:
            continue
        for c in props:
            if c.text and c.text.strip():
                d[local(c.tag)] = c.text.strip()
    return d


def resolve(value, props):
    if value is None:
        return None

    def repl(m):
        return props.get(m.group(1), m.group(0))

    for _ in range(5):
        nv = re.sub(r"\$\{([^}]+)\}", repl, value)
        if nv == value:
            break
        value = nv
    return value


def effective_props(roots, g, a, v):
    props = collect_props(roots)
    props.setdefault("project.groupId", g)
    props.setdefault("project.artifactId", a)
    props.setdefault("project.version", v)
    props.setdefault("pom.groupId", g)
    props.setdefault("pom.artifactId", a)
    props.setdefault("pom.version", v)
    for k, val in list(props.items()):
        props[k] = resolve(val, props)
    return props


def dep_management(roots, props):
    dm = {}
    for root in roots:                  # self wins over parents
        dmn = child(root, "dependencyManagement")
        if dmn is None:
            continue
        deps = child(dmn, "dependencies")
        if deps is None:
            continue
        for dep in deps:
            kg = resolve(text_of(dep, "groupId"), props)
            ka = resolve(text_of(dep, "artifactId"), props)
            if kg and ka and (kg, ka) not in dm:
                dm[(kg, ka)] = dep
    return dm


def normalize_version(v):
    """Maven version ranges: an exact single-value range such as [2.2.5] or (2.1.0)
    pins one concrete version -> use it. Anything with a comma / open interval is a
    genuine range, which we refuse to guess -> None (recorded as unresolved)."""
    if v is None:
        return None
    v = v.strip()
    m = re.fullmatch(r"[\[\(]\s*([^,\[\]\(\)]+?)\s*[\]\)]", v)
    if m:
        return m.group(1).strip()
    if "," in v or v[0] in "[(":
        return None
    return v


def parse_deps(root, props, dm):
    out = []
    deps = child(root, "dependencies")
    if deps is None:
        return out
    for dep in deps:
        g = resolve(text_of(dep, "groupId"), props)
        a = resolve(text_of(dep, "artifactId"), props)
        ver = resolve(text_of(dep, "version"), props)
        scope = (text_of(dep, "scope") or "compile").strip().lower()
        dtype = (text_of(dep, "type") or "jar").strip().lower()
        optional = (text_of(dep, "optional") or "false").strip().lower() == "true"
        exclusions = []
        ex = child(dep, "exclusions")
        if ex is not None:
            for e in ex:
                eg = text_of(e, "groupId")
                ea = text_of(e, "artifactId")
                if eg and ea:
                    exclusions.append((eg, ea))
        if not ver and (g, a) in dm:
            m = dm[(g, a)]
            mv = resolve(text_of(m, "version"), props)
            if mv:
                ver = mv
            mt = (text_of(m, "type") or "").strip().lower()
            if mt in ("aar", "jar"):
                dtype = mt
        ver = normalize_version(ver)
        out.append(dict(group=g, artifact=a, version=ver, scope=scope,
                        type=dtype, optional=optional, exclusions=exclusions))
    return out


# --------------------------------------------------------------------------
# fetch one coordinate
# --------------------------------------------------------------------------

def fetch_coordinate(g, a, v, declared_type, record):
    """Download pom + binary for g:a:v and extract. Returns (record, err)."""
    roots, repo, err = load_pom_chain(g, a, v)
    if not roots:
        return None, "pom %s" % (err or "unavailable")
    root = roots[0]
    props = effective_props(roots, g, a, v)
    dm = dep_management(roots, props)

    pom_pack = (text_of(root, "packaging") or declared_type or "jar").strip().lower()
    cands = []
    for e in (pom_pack, declared_type, "jar", "aar"):
        if e in ("jar", "aar") and e not in cands:
            cands.append(e)

    binary_path = binary_repo = binary_ext = None
    for ext in cands:
        rel = rel_path(g, a, v, "%s-%s.%s" % (a, v, ext))
        p, r = cached_download(rel)
        if p is not None:
            binary_path, binary_repo, binary_ext = p, r, ext
            break
    if binary_path is None:
        return None, "binary %s:%s:%s (%s)" % (g, a, v, "/".join(cands))

    # pom relative path (for reporting)
    rel_pom = rel_path(g, a, v, "%s-%s.pom" % (a, v))
    rec = {
        "group": g, "artifact": a, "version": v, "type": binary_ext,
        "pom_repo": repo,
        "pom_path": os.path.join(M2, rel_pom.replace("/", os.sep)),
        "binary_repo": binary_repo,
        "binary_path": binary_path,
        "binary_size": os.path.getsize(binary_path),
    }

    # ---- extract ----
    jar_out = None
    aar_dir = None
    note = None
    if binary_ext == "aar":
        with zipfile.ZipFile(binary_path) as z:
            names = z.namelist()
            if "classes.jar" in names:
                os.makedirs(JARS, exist_ok=True)
                jar_out = os.path.join(JARS, "%s-%s.jar" % (a, v))
                with z.open("classes.jar") as src, open(jar_out, "wb") as dst:
                    shutil.copyfileobj(src, dst)
            else:
                note = "aar has no classes.jar"
            aar_dir = os.path.join(AARS, "%s-%s" % (a, v))
            os.makedirs(aar_dir, exist_ok=True)
            copied = []
            for n in names:
                if n.endswith("/"):
                    continue
                if n.startswith("res/") or n in ("AndroidManifest.xml", "proguard.txt", "R.txt"):
                    target = os.path.join(aar_dir, n.replace("/", os.sep))
                    os.makedirs(os.path.dirname(target), exist_ok=True)
                    with z.open(n) as src, open(target, "wb") as dst:
                        shutil.copyfileobj(src, dst)
                    copied.append(n)
            rec["aar_files"] = sorted(copied)
    else:
        os.makedirs(JARS, exist_ok=True)
        jar_out = os.path.join(JARS, "%s-%s.jar" % (a, v))
        shutil.copyfile(binary_path, jar_out)

    rec["jar_out"] = jar_out
    rec["jar_size"] = os.path.getsize(jar_out) if jar_out else 0
    rec["aar_dir"] = aar_dir
    if note:
        rec["note"] = note
    rec["dependencies"] = parse_deps(root, props, dm)
    return rec, None


# --------------------------------------------------------------------------
# main resolution loop
# --------------------------------------------------------------------------

def main():
    for d in (M2, JARS, AARS):
        os.makedirs(d, exist_ok=True)

    records = {}        # "g:a:v" -> record
    unresolved = []     # (coord, reason)
    skipped = []        # (coord, reason)
    queue = [(ROOT_GAV[0], ROOT_GAV[1], ROOT_GAV[2], frozenset())]
    seen = set()
    t0 = time.time()

    while queue:
        g, a, v, excl = queue.pop(0)
        if (g, a) in excl:
            skipped.append(("%s:%s:%s" % (g, a, v), "excluded by parent"))
            continue
        key = "%s:%s:%s" % (g, a, v)
        if key in seen:
            continue
        seen.add(key)

        declared_type = "aar" if a == "work-runtime" else "jar"
        rec, err = fetch_coordinate(g, a, v, declared_type, None)
        if rec is None:
            unresolved.append((key, err))
            log("  [FAIL] %-60s %s" % (key, err))
            continue

        records[key] = rec
        log("  [ OK ] %-52s %-4s %8d B  <- %s" % (
            key, rec["type"], rec["binary_size"],
            rec["binary_repo"].replace("https://maven.aliyun.com/repository/", "aliyun/")
                               .replace("https://repo1.maven.org/maven2", "central")))

        for dep in rec["dependencies"]:
            dkey = "%s:%s:%s" % (dep["group"], dep["artifact"], dep["version"])
            if dep["optional"]:
                skipped.append((dkey, "optional=true"))
                continue
            if dep["scope"] in SKIP_SCOPES:
                skipped.append((dkey, "scope=%s" % dep["scope"]))
                continue
            if dep["version"] is None:
                unresolved.append((dkey, "no <version> (not in pom/dependencyManagement)"))
                log("  [WARN] %-60s missing <version>, skipped" % dkey)
                continue
            new_excl = set(excl) | set(dep["exclusions"])
            queue.append((dep["group"], dep["artifact"], dep["version"], frozenset(new_excl)))

    # ---------------- deps.json ----------------
    out = {
        "root": "%s:%s:%s" % ROOT_GAV,
        "generated_by": "tools/fetch_androidx.py",
        "repos": REPOS,
        "artifacts": [
            {
                "coordinate": k,
                "group": r["group"],
                "artifact": r["artifact"],
                "version": r["version"],
                "type": r["type"],
                "pom_repo": r["pom_repo"],
                "binary_repo": r["binary_repo"],
                "pom_path": os.path.relpath(r["pom_path"], BASE).replace("\\", "/"),
                "binary_path": os.path.relpath(r["binary_path"], BASE).replace("\\", "/"),
                "jar_path": (os.path.relpath(r["jar_out"], BASE).replace("\\", "/")
                             if r["jar_out"] else None),
                "aar_dir": (os.path.relpath(r["aar_dir"], BASE).replace("\\", "/")
                            if r["aar_dir"] else None),
                "binary_size": r["binary_size"],
                "jar_size": r["jar_size"],
            }
            for k, r in sorted(records.items())
        ],
        "unresolved": [{"coordinate": k, "reason": w} for k, w in unresolved],
        "skipped": [{"coordinate": k, "reason": w} for k, w in skipped],
    }
    with open(DEPS_JSON, "w", encoding="utf-8") as f:
        json.dump(out, f, indent=2, ensure_ascii=False)

    # ---------------- manifest table ----------------
    log("")
    log("=" * 84)
    log("MANIFEST")
    log("=" * 84)
    log("%-46s %-5s %12s %12s" % ("COORDINATE", "TYPE", "BINARY(B)", "JAR(B)"))
    log("-" * 84)
    tot_bin = tot_jar = 0
    for k in sorted(records):
        r = records[k]
        tot_bin += r["binary_size"]
        tot_jar += r["jar_size"]
        log("%-46s %-5s %12d %12d" % (k, r["type"], r["binary_size"], r["jar_size"]))
    log("-" * 84)
    log("%-46s %-5s %12d %12d" % ("TOTAL (%d artifacts)" % len(records), "", tot_bin, tot_jar))
    log("elapsed: %.1fs" % (time.time() - t0))

    # ---------------- verification A-D ----------------
    verify(records, unresolved, skipped)


# --------------------------------------------------------------------------
# verification
# --------------------------------------------------------------------------

CHECK_CLASSES = [
    "androidx/work/Worker.class",
    "androidx/work/WorkManager.class",
    "androidx/work/impl/WorkDatabase_Impl.class",
    "androidx/room/RoomDatabase.class",
    "androidx/sqlite/db/SupportSQLiteOpenHelper.class",
    "com/google/common/util/concurrent/ListenableFuture.class",
    "androidx/startup/InitializationProvider.class",
    "androidx/core/app/NotificationCompat.class",
]


def list_jars():
    if not os.path.isdir(JARS):
        return []
    return sorted(os.path.join(JARS, n) for n in os.listdir(JARS) if n.endswith(".jar"))


def verify(records, unresolved, skipped):
    log("")
    log("=" * 84)
    log("VERIFICATION A: jars are valid zips containing .class entries")
    log("=" * 84)
    jars = list_jars()
    bad = []
    entry_map = {}
    for j in jars:
        name = os.path.basename(j)
        try:
            with zipfile.ZipFile(j) as z:
                entries = [n for n in z.namelist() if n.endswith(".class")]
                if z.testzip() is not None:
                    bad.append((name, "corrupt entry"))
                entry_map[name] = set(z.namelist())
                if not entries:
                    bad.append((name, "no .class entries"))
        except Exception as e:          # noqa: BLE001
            bad.append((name, "invalid zip: %s" % e))
    log("jars checked: %d, anomalies: %d" % (len(jars), len(bad)))
    for n, why in bad:
        log("  ANOMALY: %s -> %s" % (n, why))

    log("")
    log("=" * 84)
    log("VERIFICATION B: required classes across all jars")
    log("=" * 84)
    for cls in CHECK_CLASSES:
        hits = [n for n, ents in entry_map.items() if cls in ents]
        if hits:
            log("  FOUND   %-58s in: %s" % (cls, ", ".join(hits)))
        else:
            log("  MISSING %-58s <-- not present in any jar" % cls)

    log("")
    log("=" * 84)
    log("VERIFICATION C: libs/jars size & count")
    log("=" * 84)
    total = sum(os.path.getsize(j) for j in jars)
    log("jars: %d files, total %d bytes (%.2f MiB)" % (len(jars), total, total / 1048576.0))

    log("")
    log("=" * 84)
    log("VERIFICATION D: AAR directories")
    log("=" * 84)
    if os.path.isdir(AARS):
        for d in sorted(os.listdir(AARS)):
            full = os.path.join(AARS, d)
            if not os.path.isdir(full):
                continue
            man = os.path.exists(os.path.join(full, "AndroidManifest.xml"))
            pro = os.path.exists(os.path.join(full, "proguard.txt"))
            rtxt = os.path.exists(os.path.join(full, "R.txt"))
            res = []
            for root_, _dirs, files in os.walk(os.path.join(full, "res")):
                for fn in files:
                    rel = os.path.relpath(os.path.join(root_, fn), full).replace("\\", "/")
                    res.append(rel)
            log("  %s" % d)
            log("    AndroidManifest.xml: %s | proguard.txt: %s | R.txt: %s"
                % ("YES" if man else "no", "YES" if pro else "no", "YES" if rtxt else "no"))
            if res:
                log("    res/: %s" % ", ".join(sorted(res)))
            else:
                log("    res/: (none)")

    log("")
    log("=" * 84)
    log("UNRESOLVED (%d)" % len(unresolved))
    log("=" * 84)
    for k, w in unresolved:
        log("  %-56s %s" % (k, w))
    log("")
    log("SKIPPED (%d)  [test/provided/optional/excluded]" % len(skipped))
    for k, w in skipped:
        log("  %-56s %s" % (k, w))


if __name__ == "__main__":
    main()
