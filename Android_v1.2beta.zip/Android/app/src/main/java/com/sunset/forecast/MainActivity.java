package com.sunset.forecast;

import android.Manifest;
import android.app.Activity;
import android.app.AlarmManager;
import android.app.AlertDialog;
import android.content.DialogInterface;
import android.content.Intent;
import android.content.SharedPreferences;
import android.content.pm.PackageManager;
import android.content.res.Configuration;
import android.graphics.Bitmap;
import android.graphics.Color;
import android.net.Uri;
import android.os.Build;
import android.os.Bundle;
import android.provider.Settings;
import android.view.View;
import android.view.Window;
import android.view.WindowInsets;
import android.view.WindowManager;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import com.sunset.forecast.core.Vault;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.Arrays;
import java.util.HashMap;
import java.util.Map;

/**
 * 火烧云预报 —— 原生外壳。
 *
 * 设计要点（源码保护）：
 *  1. 原始 index.html 不落盘：构建期整文件 AES-256-CBC 加密后写入 assets/app.dat；
 *     运行期只在内存中解密，通过 shouldInterceptRequest 以虚拟 HTTPS 域名回注，明文永不写盘。
 *  2. 解密密钥不以明文形式存在于 dex：Vault 中以两段 int 数组异或重组，R8 混淆类与方法名。
 *  3. 关闭 WebView 远程调试，禁用本地文件访问，避免通过 chrome://inspect 或 file:// 窃取页面源码。
 *
 * 移动端适配：
 *  4. 状态栏保持常显并按当前主题取色（浅色米白 / 深色墨底）；全面屏、刘海屏按 window insets
 *     补上边距，页面不被状态栏或挖孔遮挡；页面自带两套配色，故禁止系统再强制反色。
 *  5. 主题桥 AndroidTheme：页面读取系统深浅色并回传当前主题，状态栏、导航栏随之同步。
 *  6. JS 桥只对内部资源注入：仅当页面来自内存回注的虚拟域名（或本地 assets）时才挂载
 *     AndroidTheme；加载任何外部 URL 都不注入，并在导航离开内部资源时立即移除，
 *     避免外部页面复用原生接口造成注入攻击。
 */
public class MainActivity extends Activity {

    /** 虚拟域名：页面真实内容只在此域下由内存提供，外部无法访问。 */
    private static final String HOST = "forecast.local";
    private static final String PAGE_URL = "https://" + HOST + "/index.html";
    /** 业务脚本（app.js）同样以密文随包分发，运行期由内存回注。 */
    private static final String SCRIPT_URL = "https://" + HOST + "/app.js";
    private static final String ICON_URL = "https://" + HOST + "/icon.png";
    /** 内部资源前缀：内存回注的虚拟域名 + 本地 assets，只有此范围内的页面才注入 JS 桥接。 */
    private static final String INTERNAL_PREFIX = "https://" + HOST + "/";
    private static final String ASSET_PREFIX = "file:///android_asset/";
    /** 页面米白底色：状态栏、导航栏与 WebView 背景统一取此色，避免出现割裂色带。 */
    private static final String PAGE_BG = "#f7f4ec";
    /** 页面墨色底：深色主题下状态栏、导航栏与 WebView 背景统一取此色。 */
    private static final String DARK_BG = "#14120f";

    private WebView webView;
    /** 内存中的明文 HTML，进程退出前不清除，但从不写入磁盘。 */
    private volatile byte[] html;
    /** 内存中的明文业务脚本（app.js），同样只在运行期驻留内存。 */
    private volatile byte[] script;
    /** 主题桥是否已挂载：只对内部资源注入一次，外部页面绝不注入。 */
    private boolean themeBridgeInjected;

    /** 通知桥（AndroidInterface）是否已挂载：与主题桥同策略，只对内部资源注入。 */
    private boolean notifyBridgeInjected;

    /** 定位权限请求码 */
    private static final int REQ_LOCATION = 0x51;
    /** 通知权限请求码（Android 13+ 的 POST_NOTIFICATIONS） */
    private static final int REQ_NOTIFICATION = 0x52;
    /** 精确闹钟权限引导只弹一次，避免反复打扰 */
    private boolean exactAlarmPrompted;

    /** 首启提示「关闭电池优化」的持久标记 */
    private static final String PREFS = "firecloud_forecast";
    private static final String KEY_BATTERY_TIP = "battery_tip_shown";
    /** WebView 定位授权回调：等系统权限结果返回后再答复页面，避免权限未授予时页面直接失败 */
    private GeolocationPermissions.Callback pendingGeoCallback;
    private String pendingGeoOrigin;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);

        // ---- 0. 状态栏：保持常显，先按系统深浅色取色，页面加载后由主题控制器校正 ----
        Window window = getWindow();
        window.clearFlags(WindowManager.LayoutParams.FLAG_FULLSCREEN
                | WindowManager.LayoutParams.FLAG_LAYOUT_NO_LIMITS);
        window.addFlags(WindowManager.LayoutParams.FLAG_DRAWS_SYSTEM_BAR_BACKGROUNDS);
        final boolean sysDark = isSystemDark();
        applySystemBars(sysDark);

        // ---- 1. 内存解密受保护的页面资源（页面与业务脚本均为密文，运行期才在内存中还原） ----
        try {
            this.html = Vault.decrypt(readFully(getAssets().open("app.dat")));
            this.script = Vault.decrypt(readFully(getAssets().open("app.js.dat")));
        } catch (Throwable t) {
            // 解密失败时给出最小化的空壳，不泄露任何原始源码。
            this.html = ("<!doctype html><meta charset=\"utf-8\">"
                    + "<body style=\"background:#f7f4ec;font-family:serif;padding:40px;color:#1a1815\">"
                    + "<h3>资源校验未通过</h3><p>应用资源已损坏或被篡改，请重新安装。</p></body>")
                    .getBytes(java.nio.charset.StandardCharsets.UTF_8);
            this.script = ("/* 资源校验未通过：业务脚本不可用 */")
                    .getBytes(java.nio.charset.StandardCharsets.UTF_8);
        }

        // ---- 2. 关闭一切可被外部利用的调试/文件通道 ----
        WebView.setWebContentsDebuggingEnabled(false);

        this.webView = new WebView(this);
        this.webView.setBackgroundColor(Color.parseColor(sysDark ? DARK_BG : PAGE_BG));
        setContentView(this.webView);

        // 全面屏/刘海屏适配：把系统状态栏高度补进内容上边距，页面不被状态栏遮挡
        final int basePaddingTop = this.webView.getPaddingTop();
        this.webView.setOnApplyWindowInsetsListener(new View.OnApplyWindowInsetsListener() {
            @Override
            public WindowInsets onApplyWindowInsets(View v, WindowInsets insets) {
                v.setPadding(v.getPaddingLeft(),
                        basePaddingTop + insets.getSystemWindowInsetTop(),
                        v.getPaddingRight(), v.getPaddingBottom());
                return insets;
            }
        });
        this.webView.requestApplyInsets();

        WebSettings s = this.webView.getSettings();
        s.setJavaScriptEnabled(true);
        s.setDomStorageEnabled(true);
        s.setDatabaseEnabled(false);
        s.setAllowFileAccess(false);
        s.setAllowContentAccess(false);
        s.setAllowFileAccessFromFileURLs(false);
        s.setAllowUniversalAccessFromFileURLs(false);
        s.setJavaScriptCanOpenWindowsAutomatically(false);
        s.setSupportMultipleWindows(false);
        // 定位能力供页面「位置设置」使用（仅在开关开启或点击手动定位时才会真正触发）
        s.setGeolocationEnabled(true);
        s.setDefaultTextEncodingName("utf-8");
        s.setCacheMode(WebSettings.LOAD_DEFAULT);
        s.setMediaPlaybackRequiresUserGesture(true);
        // 移动端适配：按设备宽度排版，字号不随系统缩放放大
        s.setUseWideViewPort(true);
        s.setLoadWithOverviewMode(true);
        s.setTextZoom(100);
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.Q) {
            // 页面自带浅色/深色两套配色，禁止系统再强制反色，避免出现双重反转
            s.setForceDark(WebSettings.FORCE_DARK_OFF);
        }

        // 主题桥不在此时无条件挂载：仅当入口为内部资源（内存回注页面 / 本地 assets）时才注入，
        // 外部 URL 一律不注入；后续若导航离开内部资源，WebViewClient 会立即移除该接口。
        if (isInternalUrl(PAGE_URL)) {
            this.themeBridgeInjected = true;
            this.webView.addJavascriptInterface(new ThemeBridge(), "AndroidTheme");
            this.notifyBridgeInjected = true;
            this.webView.addJavascriptInterface(new AndroidBridge(this), "AndroidInterface");
        }

        this.webView.setWebViewClient(new WebViewClient() {

            @Override
            public void onPageStarted(WebView view, String url, Bitmap favicon) {
                // JS 桥只对内部资源注入：内部页面挂载一次，外部页面一律不注入并即时移除。
                if (isInternalUrl(url)) {
                    if (!themeBridgeInjected) {
                        themeBridgeInjected = true;
                        view.addJavascriptInterface(new ThemeBridge(), "AndroidTheme");
                    }
                    if (!notifyBridgeInjected) {
                        notifyBridgeInjected = true;
                        view.addJavascriptInterface(new AndroidBridge(MainActivity.this), "AndroidInterface");
                    }
                } else {
                    view.removeJavascriptInterface("AndroidTheme");
                    themeBridgeInjected = false;
                    view.removeJavascriptInterface("AndroidInterface");
                    notifyBridgeInjected = false;
                }
            }

            @Override
            public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                String url = request.getUrl().toString();
                if (url.equals(PAGE_URL) || url.equals(INTERNAL_PREFIX)) {
                    // 页面本体来自内存，绝不由磁盘文件对外提供。
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("Content-Type", "text/html; charset=utf-8");
                    return new WebResourceResponse(
                            "text/html", "utf-8", 200, "OK", headers,
                            new ByteArrayInputStream(html));
                }
                if (url.equals(SCRIPT_URL)) {
                    // 业务脚本（app.js）同样是密文，仅在此处于内存中还原后回注
                    Map<String, String> headers = new HashMap<>();
                    headers.put("Cache-Control", "no-store");
                    headers.put("Content-Type", "application/javascript; charset=utf-8");
                    return new WebResourceResponse(
                            "application/javascript", "utf-8", 200, "OK", headers,
                            new ByteArrayInputStream(script));
                }
                if (url.equals(ICON_URL)) {
                    // 网页图标（favicon）随包分发，直接从 assets 回注
                    try {
                        Map<String, String> headers = new HashMap<>();
                        headers.put("Cache-Control", "max-age=86400");
                        return new WebResourceResponse(
                                "image/png", "utf-8", 200, "OK", headers,
                                getAssets().open("icon.png"));
                    } catch (Throwable ignored) {
                        return null;
                    }
                }
                if (url.startsWith(INTERNAL_PREFIX)) {
                    // 虚拟域名下未声明的路径一律不对外提供，也绝不落到网络栈
                    return new WebResourceResponse(
                            "text/plain", "utf-8", 404, "Not Found",
                            new HashMap<String, String>(),
                            new ByteArrayInputStream(new byte[0]));
                }
                // 其余请求（Open-Meteo 气象接口等）走系统网络栈。
                return null;
            }

            @Override
            public boolean shouldOverrideUrlLoading(WebView view, WebResourceRequest request) {
                // 仅允许内部资源在应用内闭环；外部链接一律不加载、不跳转。
                return !isInternalUrl(request.getUrl().toString());
            }
        });

        // 定位授权：页面仅在「位置设置」开关开启或点击手动定位时才会发起定位请求；
        // 此处先申请系统权限，权限结果返回后再答复 WebView，避免权限尚未授予时页面直接失败。
        this.webView.setWebChromeClient(new WebChromeClient() {
            @Override
            public void onGeolocationPermissionsShowPrompt(String origin, GeolocationPermissions.Callback callback) {
                if (hasLocationPermission()) {
                    callback.invoke(origin, true, false);
                    return;
                }
                if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
                    pendingGeoCallback = callback;
                    pendingGeoOrigin = origin;
                    requestPermissions(new String[]{
                            Manifest.permission.ACCESS_COARSE_LOCATION,
                            Manifest.permission.ACCESS_FINE_LOCATION
                    }, REQ_LOCATION);
                } else {
                    callback.invoke(origin, false, false);
                }
            }
        });

        this.webView.loadUrl(PAGE_URL);

        // ---- 3. 通知能力准备 ----
        // 通知渠道固定 firecloud_alert；Android 13+ 动态申请 POST_NOTIFICATIONS；
        // 首启提示国产系统需关闭电池优化 / 允许后台活动；并登记周期后台刷新与重排已存提醒。
        NotifyCenter.ensureChannel(this);
        ensureNotificationPermission();
        maybeShowBatteryTip();
        RemindWorker.schedulePeriodic(this);
        RemindScheduler.rescheduleAll(this);
    }

    /** Android 13+ 发通知需要运行时权限，未授予时在启动后引导用户授权。 */
    private void ensureNotificationPermission() {
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU
                && checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                != PackageManager.PERMISSION_GRANTED) {
            requestPermissions(new String[]{Manifest.permission.POST_NOTIFICATIONS}, REQ_NOTIFICATION);
        }
    }

    /** Android 12+ 精确闹钟权限：未授予时引导用户到系统设置开启，只弹一次。 */
    private void promptExactAlarmIfNeeded() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S || this.exactAlarmPrompted) return;
        AlarmManager am = (AlarmManager) getSystemService(ALARM_SERVICE);
        if (am == null || am.canScheduleExactAlarms()) return;
        this.exactAlarmPrompted = true;
        new AlertDialog.Builder(this)
                .setTitle("允许「闹钟与提醒」")
                .setMessage("为了让霞情提醒在预报时刻准点推送，请允许本应用使用精确闹钟。")
                .setPositiveButton("去设置", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            startActivity(new Intent(Settings.ACTION_REQUEST_SCHEDULE_EXACT_ALARM,
                                    Uri.parse("package:" + getPackageName())));
                        } catch (Throwable ignored) { }
                    }
                })
                .setNegativeButton("稍后", null)
                .show();
    }

    /** 首次启动提示：国产安卓系统需关闭电池优化 / 允许后台活动，否则定时提醒会被系统拦下。 */
    private void maybeShowBatteryTip() {
        final SharedPreferences sp = getSharedPreferences(PREFS, MODE_PRIVATE);
        if (sp.getBoolean(KEY_BATTERY_TIP, false)) return;
        sp.edit().putBoolean(KEY_BATTERY_TIP, true).apply();
        new AlertDialog.Builder(this)
                .setTitle("让提醒不被系统拦下")
                .setMessage("国产安卓系统（华为 / 小米 / OPPO / vivo 等）默认限制后台应用。\n"
                        + "请为本应用关闭「电池优化」、允许「后台活动」与「自启动」，"
                        + "否则定时通知可能无法触发。")
                .setPositiveButton("去设置", new DialogInterface.OnClickListener() {
                    @Override
                    public void onClick(DialogInterface dialog, int which) {
                        try {
                            startActivity(new Intent(Settings.ACTION_IGNORE_BATTERY_OPTIMIZATION_SETTINGS));
                        } catch (Throwable ignored) { }
                    }
                })
                .setNegativeButton("知道了", null)
                .show();
    }

    /** 网页端排好提醒后的回调（在原生侧线程调用）：补齐权限引导并登记后台刷新。 */
    void onRemindTasksScheduled() {
        runOnUiThread(new Runnable() {
            @Override
            public void run() {
                ensureNotificationPermission();
                promptExactAlarmIfNeeded();
                RemindWorker.schedulePeriodic(MainActivity.this);
            }
        });
    }

    @Override
    public void onBackPressed() {
        if (this.webView != null && this.webView.canGoBack()) {
            this.webView.goBack();
        } else {
            super.onBackPressed();
        }
    }

    @Override
    protected void onDestroy() {
        if (this.html != null) {
            Arrays.fill(this.html, (byte) 0);
        }
        if (this.script != null) {
            Arrays.fill(this.script, (byte) 0);
        }
        if (this.webView != null) {
            this.webView.destroy();
        }
        super.onDestroy();
    }

    /** 是否为本应用内部资源（内存回注的虚拟域名 / 本地 assets），据此决定是否注入 JS 桥接。 */
    private boolean isInternalUrl(String url) {
        if (url == null) return false;
        return url.startsWith(INTERNAL_PREFIX) || url.startsWith(ASSET_PREFIX);
    }

    @Override
    public void onConfigurationChanged(Configuration newConfig) {
        super.onConfigurationChanged(newConfig);
        // 系统深浅色切换：页面若处于“跟随系统”档位，会立即重新取色并回调主题桥
        if (this.webView != null) {
            this.webView.evaluateJavascript(
                    "window.__applyThemeFromSystem && window.__applyThemeFromSystem();", null);
        }
    }

    /** 系统当前是否处于深色模式（“跟随系统”档位据此判定）。 */
    private boolean isSystemDark() {
        int uiMode = getResources().getConfiguration().uiMode & Configuration.UI_MODE_NIGHT_MASK;
        return uiMode == Configuration.UI_MODE_NIGHT_YES;
    }

    /** 状态栏与导航栏：浅色主题取页面米白，深色主题取页面墨底，图标明暗随之切换。 */
    private void applySystemBars(boolean dark) {
        Window window = getWindow();
        int bar = Color.parseColor(dark ? DARK_BG : PAGE_BG);
        window.setStatusBarColor(bar);
        window.setNavigationBarColor(bar);
        View decor = window.getDecorView();
        int flags = decor.getSystemUiVisibility();
        if (dark) {
            flags &= ~View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        } else {
            flags |= View.SYSTEM_UI_FLAG_LIGHT_STATUS_BAR;
        }
        decor.setSystemUiVisibility(flags);
    }

    /** 页面主题桥：仅暴露“系统深浅色查询”与“同步状态栏配色”两个方法。 */
    public class ThemeBridge {

        @JavascriptInterface
        public boolean isDark() {
            return isSystemDark();
        }

        @JavascriptInterface
        public void setTheme(String mode) {
            final boolean dark = "dark".equals(mode);
            runOnUiThread(new Runnable() {
                @Override
                public void run() {
                    applySystemBars(dark);
                    if (webView != null) {
                        webView.setBackgroundColor(Color.parseColor(dark ? DARK_BG : PAGE_BG));
                    }
                }
            });
        }
    }

    /** 是否已获得定位权限（Android 6.0 以下安装即授予）。 */
    private boolean hasLocationPermission() {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.M) return true;
        return checkSelfPermission(Manifest.permission.ACCESS_COARSE_LOCATION) == PackageManager.PERMISSION_GRANTED
                || checkSelfPermission(Manifest.permission.ACCESS_FINE_LOCATION) == PackageManager.PERMISSION_GRANTED;
    }

    @Override
    public void onRequestPermissionsResult(int requestCode, String[] permissions, int[] grantResults) {
        super.onRequestPermissionsResult(requestCode, permissions, grantResults);
        if (requestCode == REQ_LOCATION && this.pendingGeoCallback != null) {
            boolean granted = false;
            if (grantResults != null) {
                for (int r : grantResults) {
                    if (r == PackageManager.PERMISSION_GRANTED) { granted = true; break; }
                }
            }
            this.pendingGeoCallback.invoke(this.pendingGeoOrigin, granted, false);
            this.pendingGeoCallback = null;
            this.pendingGeoOrigin = null;
        }
    }

    private static byte[] readFully(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(1024, in.available()));
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            try { in.close(); } catch (Exception ignored) { }
        }
    }
}
