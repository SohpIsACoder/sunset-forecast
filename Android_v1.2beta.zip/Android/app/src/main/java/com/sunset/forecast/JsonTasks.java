package com.sunset.forecast;

import org.json.JSONArray;
import org.json.JSONObject;

import java.util.ArrayList;
import java.util.List;

/**
 * 解析网页端传来的提醒任务 JSON。
 *
 * 前台（addRemindTask）直接是一个数组：
 *   [{ key, time, title, content, ... }, ...]
 * 后台无界面模式回包（onHeadlessDone）是一个信封对象：
 *   { ok, city, mode, tasks: [ ... ] }
 */
final class JsonTasks {

    private JsonTasks() {}

    /** 解析任务数组；只保留未来时刻，已过期的直接丢弃。 */
    static List<RemindStore.Task> parse(String json) {
        List<RemindStore.Task> out = new ArrayList<RemindStore.Task>();
        try {
            String body = (json == null || json.trim().isEmpty()) ? "[]" : json;
            JSONArray arr = new JSONArray(body);
            long now = System.currentTimeMillis();
            for (int i = 0; i < arr.length(); i++) {
                JSONObject o = arr.optJSONObject(i);
                if (o == null) continue;
                RemindStore.Task t = new RemindStore.Task();
                t.slot = o.optString("slot", "");
                t.at = o.optLong("time", 0L);
                t.title = o.optString("title", "火烧云霞情提醒");
                t.content = o.optString("content", "");
                t.level = o.optInt("level", 0);
                if (t.at > now) out.add(t);
            }
        } catch (Throwable ignored) { }
        return out;
    }

    /** 解析无界面模式的回包信封；ok=false 时返回空清单（等价于清空待办）。 */
    static List<RemindStore.Task> parseEnvelope(String json) {
        try {
            JSONObject o = new JSONObject(json == null ? "{}" : json);
            if (!o.optBoolean("ok", false)) return new ArrayList<RemindStore.Task>();
            JSONArray arr = o.optJSONArray("tasks");
            return parse(arr == null ? "[]" : arr.toString());
        } catch (Throwable ignored) {
            return new ArrayList<RemindStore.Task>();
        }
    }
}
