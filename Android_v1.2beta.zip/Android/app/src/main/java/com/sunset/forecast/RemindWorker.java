package com.sunset.forecast;

import android.content.Context;
import android.os.Handler;
import android.os.Looper;
import android.webkit.GeolocationPermissions;
import android.webkit.JavascriptInterface;
import android.webkit.WebChromeClient;
import android.webkit.WebResourceRequest;
import android.webkit.WebResourceResponse;
import android.webkit.WebSettings;
import android.webkit.WebView;
import android.webkit.WebViewClient;

import androidx.work.Constraints;
import androidx.work.ExistingPeriodicWorkPolicy;
import androidx.work.NetworkType;
import androidx.work.PeriodicWorkRequest;
import androidx.work.WorkManager;
import androidx.work.Worker;
import androidx.work.WorkerParameters;

import com.sunset.forecast.core.Vault;

import java.io.ByteArrayInputStream;
import java.io.ByteArrayOutputStream;
import java.io.InputStream;
import java.util.HashMap;
import java.util.List;
import java.util.Map;
import java.util.concurrent.CountDownLatch;
import java.util.concurrent.TimeUnit;

/**
 * 后台周期刷新（WorkManager 轨道）。
 *
 * 思路：在无界面 WebView 里加载本地受保护页面（?headless=1），复用网页里那一整套
 * 定位 → 拉取 GFS/EC/CAMS → 火烧云评分 逻辑，算完由网页调用 onHeadlessDone 回传，
 * 原生侧落库并用 AlarmManager 重排提醒。JS 评分算法完全保留、不迁移到原生。
 *
 * 定时调度全部在原生层完成；页面不注册任何 JS 定时器。
 */
public final class RemindWorker extends Worker {

    private static final String WORK_NAME = "firecloud_model_refresh";
    /** Open-Meteo 模型约每 6 小时更新一次，按同样节奏后台复算。 */
    private static final long INTERVAL_HOURS = 6L;
    private static final long WAIT_SECONDS = 120L;

    private static final String HOST = "forecast.local";
    private static final String PAGE_URL = "https://" + HOST + "/index.html";
    private static final String SCRIPT_URL = "https://" + HOST + "/app.js";
    private static final String ICON_URL = "https://" + HOST + "/icon.png";
    private static final String INTERNAL_PREFIX = "https://" + HOST + "/";

    public RemindWorker(Context context, WorkerParameters params) {
        super(context, params);
    }

    /** 登记唯一的周期后台刷新任务（重复调用不会重复入队）。 */
    static void schedulePeriodic(Context ctx) {
        try {
            Constraints c = new Constraints.Builder()
                    .setRequiredNetworkType(NetworkType.CONNECTED)
                    .build();
            PeriodicWorkRequest req = new PeriodicWorkRequest.Builder(
                    RemindWorker.class, INTERVAL_HOURS, TimeUnit.HOURS)
                    .setConstraints(c)
                    .build();
            WorkManager.getInstance(ctx.getApplicationContext())
                    .enqueueUniquePeriodicWork(WORK_NAME, ExistingPeriodicWorkPolicy.KEEP, req);
        } catch (Throwable ignored) { }
    }

    @Override
    public Result doWork() {
        final Context ctx = getApplicationContext();
        final CountDownLatch latch = new CountDownLatch(1);
        final WebView[] holder = new WebView[1];

        new Handler(Looper.getMainLooper()).post(new Runnable() {
            @Override
            public void run() {
                try {
                    final byte[] html = Vault.decrypt(readFully(ctx.getAssets().open("app.dat")));
                    final byte[] script = Vault.decrypt(readFully(ctx.getAssets().open("app.js.dat")));

                    WebView wv = new WebView(ctx);
                    holder[0] = wv;

                    WebSettings s = wv.getSettings();
                    s.setJavaScriptEnabled(true);
                    s.setDomStorageEnabled(true);
                    s.setDatabaseEnabled(false);
                    s.setGeolocationEnabled(true);
                    s.setAllowFileAccess(false);
                    s.setAllowContentAccess(false);
                    s.setAllowFileAccessFromFileURLs(false);
                    s.setAllowUniversalAccessFromFileURLs(false);
                    s.setBlockNetworkLoads(false);
                    s.setCacheMode(WebSettings.LOAD_DEFAULT);

                    // 无界面页面通过同一个桥名回传结果
                    wv.addJavascriptInterface(new Done(ctx, latch), "AndroidInterface");

                    wv.setWebChromeClient(new WebChromeClient() {
                        @Override
                        public void onGeolocationPermissionsShowPrompt(String origin,
                                                                       GeolocationPermissions.Callback callback) {
                            // 后台定位由系统权限是否已授予决定；此处只负责答复 WebView
                            callback.invoke(origin, true, false);
                        }
                    });

                    wv.setWebViewClient(new WebViewClient() {
                        @Override
                        public WebResourceResponse shouldInterceptRequest(WebView view, WebResourceRequest request) {
                            String url = request.getUrl().toString();
                            if (url.equals(PAGE_URL) || url.equals(INTERNAL_PREFIX)) {
                                Map<String, String> h = new HashMap<String, String>();
                                h.put("Cache-Control", "no-store");
                                h.put("Content-Type", "text/html; charset=utf-8");
                                return new WebResourceResponse("text/html", "utf-8", 200, "OK", h,
                                        new ByteArrayInputStream(html));
                            }
                            if (url.equals(SCRIPT_URL)) {
                                Map<String, String> h = new HashMap<String, String>();
                                h.put("Cache-Control", "no-store");
                                h.put("Content-Type", "application/javascript; charset=utf-8");
                                return new WebResourceResponse("application/javascript", "utf-8", 200, "OK", h,
                                        new ByteArrayInputStream(script));
                            }
                            if (url.equals(ICON_URL)) {
                                try {
                                    Map<String, String> h = new HashMap<String, String>();
                                    h.put("Cache-Control", "max-age=86400");
                                    return new WebResourceResponse("image/png", "utf-8", 200, "OK", h,
                                            ctx.getAssets().open("icon.png"));
                                } catch (Throwable ignored) {
                                    return null;
                                }
                            }
                            if (url.startsWith(INTERNAL_PREFIX)) {
                                return new WebResourceResponse("text/plain", "utf-8", 404, "Not Found",
                                        new HashMap<String, String>(), new ByteArrayInputStream(new byte[0]));
                            }
                            return null;
                        }

                        @Override
                        public void onPageFinished(WebView view, String url) {
                            // 页面与业务脚本就绪后，触发无界面计算流程
                            view.evaluateJavascript(
                                    "window.__startHeadless && window.__startHeadless();", null);
                        }
                    });

                    wv.loadUrl(PAGE_URL + "?headless=1");
                } catch (Throwable t) {
                    latch.countDown();
                }
            }
        });

        boolean ok;
        try {
            ok = latch.await(WAIT_SECONDS, TimeUnit.SECONDS);
        } catch (InterruptedException e) {
            ok = false;
        }

        final WebView wv = holder[0];
        if (wv != null) {
            new Handler(Looper.getMainLooper()).post(new Runnable() {
                @Override
                public void run() {
                    try { wv.destroy(); } catch (Throwable ignored) { }
                }
            });
        }
        return ok ? Result.success() : Result.retry();
    }

    private static byte[] readFully(InputStream in) throws Exception {
        try {
            ByteArrayOutputStream out = new ByteArrayOutputStream(Math.max(1024, in.available()));
            byte[] buf = new byte[8192];
            int n;
            while ((n = in.read(buf)) != -1) {
                out.write(buf, 0, n);
            }
            return out.toByteArray();
        } finally {
            try { in.close(); } catch (Exception ignored) { }
        }
    }

    /** 无界面页面使用的 JS 桥：算法仍在网页里跑，原生只负责落库 + 排闹钟。 */
    public static final class Done {

        private final Context ctx;
        private final CountDownLatch latch;

        Done(Context ctx, CountDownLatch latch) {
            this.ctx = ctx;
            this.latch = latch;
        }

        @JavascriptInterface
        public void showLocalNotification(String title, String content) {
            String t = (title == null || title.isEmpty()) ? "火烧云霞情提醒" : title;
            NotifyCenter.show(ctx, (int) (System.currentTimeMillis() & 0x0fffffff), t,
                    content == null ? "" : content);
        }

        @JavascriptInterface
        public void addRemindTask(String jsonStr) {
            List<RemindStore.Task> tasks = JsonTasks.parse(jsonStr);
            RemindScheduler.applyTasks(ctx, tasks);
        }

        @JavascriptInterface
        public void onHeadlessDone(String jsonStr) {
            try {
                List<RemindStore.Task> tasks = JsonTasks.parseEnvelope(jsonStr);
                RemindScheduler.applyTasks(ctx, tasks);
            } catch (Throwable ignored) {
            } finally {
                latch.countDown();
            }
        }
    }
}
