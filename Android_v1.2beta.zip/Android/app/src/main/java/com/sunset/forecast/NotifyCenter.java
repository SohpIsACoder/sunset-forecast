package com.sunset.forecast;

import android.Manifest;
import android.app.NotificationChannel;
import android.app.NotificationManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.content.pm.PackageManager;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.os.Build;

import androidx.core.app.NotificationCompat;
import androidx.core.app.NotificationManagerCompat;

/**
 * 本地通知出口。
 *
 *  · 通知渠道固定为 firecloud_alert（渠道名「火烧云霞情提醒」）；
 *  · 小图标使用 APP 自身图标（applicationInfo.icon，状态栏仅支持单色剪影）；
 *  · 大图标按火烧云等级取对应插画（res/drawable-nodpi/l1~l8），
 *    在通知卡片 / 横幅左侧以彩色方式呈现，据此区分不同火烧云程度。
 */
final class NotifyCenter {

    /** 通知渠道 ID：与需求一致，固定不可改。 */
    static final String CHANNEL_ID = "firecloud_alert";
    private static final String CHANNEL_NAME = "火烧云霞情提醒";

    private NotifyCenter() {}

    /** 是否允许发通知（Android 13+ 需要运行时权限 POST_NOTIFICATIONS）。 */
    static boolean canPost(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.TIRAMISU) return true;
        try {
            return ctx.checkSelfPermission(Manifest.permission.POST_NOTIFICATIONS)
                    == PackageManager.PERMISSION_GRANTED;
        } catch (Throwable t) {
            return false;
        }
    }

    /** 创建通知渠道（Android 8.0+，重复创建无副作用）。 */
    static void ensureChannel(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.O) return;
        try {
            NotificationManager nm =
                    (NotificationManager) ctx.getSystemService(Context.NOTIFICATION_SERVICE);
            if (nm == null || nm.getNotificationChannel(CHANNEL_ID) != null) return;
            NotificationChannel ch = new NotificationChannel(
                    CHANNEL_ID, CHANNEL_NAME, NotificationManager.IMPORTANCE_HIGH);
            ch.setDescription("朝霞 / 晚霞达到预设等级时提醒");
            ch.enableLights(false);
            ch.enableVibration(true);
            ch.setShowBadge(true);
            nm.createNotificationChannel(ch);
        } catch (Throwable ignored) { }
    }

    /** APP 自身图标：直接取自 applicationInfo.icon（launcher 图标资源）。 */
    private static int appIcon(Context ctx) {
        try {
            int id = ctx.getApplicationInfo().icon;
            if (id != 0) return id;
        } catch (Throwable ignored) { }
        return android.R.drawable.ic_dialog_info;
    }

    /** 火烧云等级 1~8 → 对应插画资源；0 或越界返回 0（表示不设置大图标）。 */
    private static int levelDrawable(int level) {
        switch (level) {
            case 1: return R.drawable.l1;
            case 2: return R.drawable.l2;
            case 3: return R.drawable.l3;
            case 4: return R.drawable.l4;
            case 5: return R.drawable.l5;
            case 6: return R.drawable.l6;
            case 7: return R.drawable.l7;
            case 8: return R.drawable.l8;
            default: return 0;
        }
    }

    /** 按等级解码通知大图标位图；解码失败或等级未知返回 null。 */
    private static Bitmap levelLargeIcon(Context ctx, int level) {
        int res = levelDrawable(level);
        if (res == 0) return null;
        try {
            return BitmapFactory.decodeResource(ctx.getResources(), res);
        } catch (Throwable t) {
            return null;
        }
    }

    /** 弹出一条本地通知（不区分火烧云等级，使用 APP 图标）。 */
    static void show(Context ctx, int id, String title, String content) {
        show(ctx, id, title, content, 0);
    }

    /**
     * 弹出一条本地通知。
     *
     * @param id 通知 ID（同 ID 会覆盖旧通知，此处按任务 ID 传入，保证互不覆盖）
     * @param level 火烧云等级 1~8，用于选取通知大图标；0 表示不设置大图标
     */
    static void show(Context ctx, int id, String title, String content, int level) {
        if (!canPost(ctx)) return;
        ensureChannel(ctx);

        Intent open = new Intent(ctx, MainActivity.class);
        open.setFlags(Intent.FLAG_ACTIVITY_NEW_TASK | Intent.FLAG_ACTIVITY_CLEAR_TOP);
        int piFlags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            piFlags |= PendingIntent.FLAG_IMMUTABLE;
        }
        PendingIntent pi = PendingIntent.getActivity(ctx, id, open, piFlags);

        NotificationCompat.Builder b = new NotificationCompat.Builder(ctx, CHANNEL_ID)
                .setSmallIcon(appIcon(ctx))
                .setContentTitle(title == null || title.isEmpty() ? "火烧云霞情提醒" : title)
                .setContentText(content == null ? "" : content)
                .setStyle(new NotificationCompat.BigTextStyle().bigText(content == null ? "" : content))
                .setAutoCancel(true)
                .setContentIntent(pi)
                .setPriority(NotificationCompat.PRIORITY_HIGH)
                .setCategory(NotificationCompat.CATEGORY_REMINDER);

        Bitmap big = levelLargeIcon(ctx, level);
        if (big != null) b.setLargeIcon(big);

        try {
            NotificationManagerCompat.from(ctx).notify(id, b.build());
        } catch (Throwable ignored) { }
    }
}
