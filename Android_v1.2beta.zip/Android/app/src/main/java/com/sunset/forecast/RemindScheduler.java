package com.sunset.forecast;

import android.app.AlarmManager;
import android.app.PendingIntent;
import android.content.Context;
import android.content.Intent;
import android.net.Uri;
import android.os.Build;

import java.util.List;

/**
 * 定时调度层（AlarmManager 轨道）。
 *
 * WorkManager 负责「到点前把数据算好」，本类负责「到点准点弹出通知」：
 * 每个任务用一个精确闹钟（setExactAndAllowWhileIdle）指向 RemindReceiver，
 * 全部时间点来自本地 SQLite，不依赖 WebView 内的 JS 定时器。
 * Android 12+ 未授予精确闹钟权限时自动退化为 setAndAllowWhileIdle（仍然可触发，只是不保证秒级准时）。
 */
final class RemindScheduler {

    static final String ACTION_REMIND = "com.sunset.forecast.action.REMIND";

    private RemindScheduler() {}

    /** 是否可排精确闹钟（Android 12+ 需用户在系统设置中允许）。 */
    static boolean canScheduleExact(Context ctx) {
        if (Build.VERSION.SDK_INT < Build.VERSION_CODES.S) return true;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        try {
            return am != null && am.canScheduleExactAlarms();
        } catch (Throwable t) {
            return false;
        }
    }

    private static PendingIntent pendingFor(Context ctx, long id) {
        Intent i = new Intent(ctx, RemindReceiver.class);
        i.setAction(ACTION_REMIND);
        i.setData(Uri.parse("firecloud://remind/" + id));
        i.putExtra("id", id);
        int flags = PendingIntent.FLAG_UPDATE_CURRENT;
        if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.M) {
            flags |= PendingIntent.FLAG_IMMUTABLE;
        }
        return PendingIntent.getBroadcast(ctx, (int) (id & 0x7fffffff), i, flags);
    }

    static void cancel(Context ctx, long id) {
        try {
            AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
            if (am != null) am.cancel(pendingFor(ctx, id));
        } catch (Throwable ignored) { }
    }

    static void schedule(Context ctx, RemindStore.Task t) {
        if (t == null || t.at <= System.currentTimeMillis()) return;
        AlarmManager am = (AlarmManager) ctx.getSystemService(Context.ALARM_SERVICE);
        if (am == null) return;
        PendingIntent pi = pendingFor(ctx, t.id);
        try {
            if (canScheduleExact(ctx)) {
                am.setExactAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.at, pi);
            } else {
                am.setAndAllowWhileIdle(AlarmManager.RTC_WAKEUP, t.at, pi);
            }
        } catch (Throwable ignored) { }
    }

    /**
     * 用新任务清单整体替换待办并重排闹钟。
     * 空清单即「关闭通知」，会把所有未触发的旧闹钟一并撤销。
     *
     * @return 实际排入的任务条数
     */
    static int applyTasks(Context ctx, List<RemindStore.Task> tasks) {
        RemindStore store = new RemindStore(ctx);
        try {
            List<Long> removed = store.replacePending(tasks);
            for (Long id : removed) {
                cancel(ctx, id.longValue());
            }
            for (RemindStore.Task t : tasks) {
                schedule(ctx, t);
            }
            return tasks.size();
        } catch (Throwable t) {
            return 0;
        } finally {
            try { store.close(); } catch (Throwable ignored) { }
        }
    }

    /** 开机 / 改时间 / 时区变化后重排未来的待办闹钟。 */
    static void rescheduleAll(Context ctx) {
        RemindStore store = new RemindStore(ctx);
        try {
            for (RemindStore.Task t : store.pending()) {
                schedule(ctx, t);
            }
        } catch (Throwable ignored) {
        } finally {
            try { store.close(); } catch (Throwable ignored) { }
        }
    }
}
