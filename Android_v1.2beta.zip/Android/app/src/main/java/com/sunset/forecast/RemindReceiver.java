package com.sunset.forecast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 精确闹钟到点回调：弹出系统本地通知，并把该任务标记为「已触发」。
 * 由 RemindScheduler 通过 AlarmManager 唤起，与 WebView / JS 无关。
 */
public final class RemindReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null || !RemindScheduler.ACTION_REMIND.equals(intent.getAction())) return;

        long id = intent.getLongExtra("id", -1L);
        RemindStore store = new RemindStore(context);
        try {
            RemindStore.Task t = id >= 0 ? store.find(id) : null;
            String title = (t != null) ? t.title : "火烧云霞情提醒";
            String content = (t != null) ? t.content : "";
            int level = (t != null) ? t.level : 0;
            NotifyCenter.show(context, (int) (id & 0x7fffffff), title, content, level);
            if (t != null) store.markFired(t.id);
        } catch (Throwable ignored) {
        } finally {
            try { store.close(); } catch (Throwable ignored) { }
        }
    }
}
