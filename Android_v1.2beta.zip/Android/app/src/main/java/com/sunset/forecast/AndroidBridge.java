package com.sunset.forecast;

import android.webkit.JavascriptInterface;

import java.util.List;

/**
 * 网页 ⇄ 原生 的 JS 桥（注入名固定为 AndroidInterface）。
 *
 * 只对内部资源注入（由 MainActivity 按 isInternalUrl 控制），外部页面绝不注入。
 * 方法名与参数签名由网页端按名调用，proguard 用 @JavascriptInterface 注解规则保留。
 */
public final class AndroidBridge {

    private final MainActivity host;

    AndroidBridge(MainActivity host) {
        this.host = host;
    }

    /**
     * ① 立即弹出一条本地通知。
     *    渠道固定 firecloud_alert，小图标取 APP 自身图标；Android 13+ 由宿主申请 POST_NOTIFICATIONS。
     */
    @JavascriptInterface
    public void showLocalNotification(String title, String content) {
        final MainActivity activity = this.host;
        final String t = (title == null || title.isEmpty()) ? "火烧云霞情提醒" : title;
        final String c = (content == null) ? "" : content;
        final int id = (int) (System.currentTimeMillis() & 0x0fffffff);
        activity.runOnUiThread(new Runnable() {
            @Override
            public void run() {
                NotifyCenter.show(activity, id, t, c);
            }
        });
    }

    /**
     * ② 接收网页传来的提醒任务 JSON 数组：存本地 SQLite，并由原生层用闹钟定时。
     *    传空数组表示关闭通知 / 清空全部待办。
     *    定时调度全部在原生层完成，不依赖 WebView 内的 JS 定时器。
     */
    @JavascriptInterface
    public void addRemindTask(String jsonStr) {
        final MainActivity activity = this.host;
        final List<RemindStore.Task> tasks = JsonTasks.parse(jsonStr);
        new Thread(new Runnable() {
            @Override
            public void run() {
                RemindScheduler.applyTasks(activity, tasks);
                if (!tasks.isEmpty()) {
                    activity.onRemindTasksScheduled();
                }
            }
        }, "firecloud-remind-apply").start();
    }

    /**
     * ③ 后台无界面模式的结果回传（网页在 ?headless=1 下算完后主动调用）。
     *    信封格式 { ok, city, mode, tasks:[...] }。
     */
    @JavascriptInterface
    public void onHeadlessDone(String jsonStr) {
        final MainActivity activity = this.host;
        final List<RemindStore.Task> tasks = JsonTasks.parseEnvelope(jsonStr);
        new Thread(new Runnable() {
            @Override
            public void run() {
                RemindScheduler.applyTasks(activity, tasks);
            }
        }, "firecloud-remind-headless").start();
    }
}
