package com.sunset.forecast;

import android.content.BroadcastReceiver;
import android.content.Context;
import android.content.Intent;

/**
 * 开机 / 系统时间或时区变化后：
 *  · 重排全部未来的精准提醒闹钟（AlarmManager 在重启后会失效）；
 *  · 重新登记周期后台刷新任务（WorkManager 自身也会重排，这里只是兜底）。
 */
public final class BootReceiver extends BroadcastReceiver {

    @Override
    public void onReceive(Context context, Intent intent) {
        if (intent == null) return;
        String action = intent.getAction();
        if (Intent.ACTION_BOOT_COMPLETED.equals(action)
                || Intent.ACTION_TIME_CHANGED.equals(action)
                || Intent.ACTION_TIMEZONE_CHANGED.equals(action)
                || "android.intent.action.QUICKBOOT_POWERON".equals(action)) {
            RemindScheduler.rescheduleAll(context);
            RemindWorker.schedulePeriodic(context);
        }
    }
}
