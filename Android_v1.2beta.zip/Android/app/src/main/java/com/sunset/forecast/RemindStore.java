package com.sunset.forecast;

import android.content.ContentValues;
import android.content.Context;
import android.database.Cursor;
import android.database.sqlite.SQLiteDatabase;
import android.database.sqlite.SQLiteOpenHelper;

import java.util.ArrayList;
import java.util.List;

/**
 * 提醒任务的本地 SQLite 持久化。
 *
 * 表 remind_task：一条记录 = 一个「到点要推送」的时刻。
 * 数据来源有两处，写入同一张表：
 *   ① 前台网页算完霞情后经 AndroidInterface.addRemindTask 传入；
 *   ② 后台 WorkManager 无界面 WebView 算完后经 onHeadlessDone 传入。
 */
final class RemindStore extends SQLiteOpenHelper {

    private static final String DB_NAME = "firecloud_remind.db";
    private static final int DB_VERSION = 2;
    private static final String TABLE = "remind_task";

    RemindStore(Context ctx) {
        super(ctx.getApplicationContext(), DB_NAME, null, DB_VERSION);
    }

    @Override
    public void onCreate(SQLiteDatabase db) {
        db.execSQL("CREATE TABLE IF NOT EXISTS " + TABLE + " ("
                + "id INTEGER PRIMARY KEY AUTOINCREMENT,"
                + "slot TEXT,"
                + "fire_at INTEGER NOT NULL,"
                + "title TEXT,"
                + "content TEXT,"
                + "level INTEGER,"
                + "fired INTEGER NOT NULL DEFAULT 0)");
    }

    @Override
    public void onUpgrade(SQLiteDatabase db, int oldVersion, int newVersion) {
        db.execSQL("DROP TABLE IF EXISTS " + TABLE);
        onCreate(db);
    }

    /** 一条待推送的提醒任务。 */
    static final class Task {
        long id;
        String slot = "";
        long at;
        String title = "";
        String content = "";
        /** 火烧云等级 1~8，用于挑选通知大图标；0 表示未知（退化为 APP 图标）。 */
        int level = 0;
    }

    private static Task read(Cursor c) {
        Task t = new Task();
        t.id = c.getLong(c.getColumnIndexOrThrow("id"));
        t.slot = c.getString(c.getColumnIndexOrThrow("slot"));
        t.at = c.getLong(c.getColumnIndexOrThrow("fire_at"));
        t.title = c.getString(c.getColumnIndexOrThrow("title"));
        t.content = c.getString(c.getColumnIndexOrThrow("content"));
        t.level = c.getInt(c.getColumnIndexOrThrow("level"));
        return t;
    }

    /**
     * 用新的任务清单整体替换「未触发」的待办（旧的已触发记录保留，避免重复提醒）。
     *
     * @return 被清掉的旧待办 ID 列表，调用方据此撤销对应闹钟。
     */
    List<Long> replacePending(List<Task> tasks) {
        List<Long> removed = new ArrayList<Long>();
        SQLiteDatabase db = getWritableDatabase();
        db.beginTransaction();
        try {
            Cursor c = db.query(TABLE, new String[]{"id"}, "fired=0", null, null, null, null);
            try {
                while (c.moveToNext()) removed.add(c.getLong(0));
            } finally {
                c.close();
            }
            db.delete(TABLE, "fired=0", null);
            for (RemindStore.Task t : tasks) {
                ContentValues cv = new ContentValues();
                cv.put("slot", t.slot);
                cv.put("fire_at", t.at);
                cv.put("title", t.title);
                cv.put("content", t.content);
                cv.put("level", t.level);
                cv.put("fired", 0);
                t.id = db.insert(TABLE, null, cv);
            }
            db.setTransactionSuccessful();
        } finally {
            db.endTransaction();
        }
        return removed;
    }

    /** 尚未触发且仍在未来的待办（按时间升序）。 */
    List<Task> pending() {
        List<Task> out = new ArrayList<Task>();
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE, null, "fired=0", null, null, null, "fire_at ASC");
        try {
            while (c.moveToNext()) out.add(read(c));
        } finally {
            c.close();
        }
        return out;
    }

    Task find(long id) {
        SQLiteDatabase db = getReadableDatabase();
        Cursor c = db.query(TABLE, null, "id=?", new String[]{String.valueOf(id)},
                null, null, null);
        try {
            if (c.moveToFirst()) return read(c);
        } finally {
            c.close();
        }
        return null;
    }

    void markFired(long id) {
        ContentValues cv = new ContentValues();
        cv.put("fired", 1);
        getWritableDatabase().update(TABLE, cv, "id=?", new String[]{String.valueOf(id)});
    }
}
