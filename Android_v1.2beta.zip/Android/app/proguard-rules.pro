# ============================================================
#  R8 / ProGuard 混淆规则 —— 源码保护
# ============================================================
# 入口 Activity 必须保留全限定类名，因为 APK 清单中直接以
# com.sunset.forecast.MainActivity 引用它；其余类（如解密核心 Vault）
# 会被 R8 混淆类名 / 方法名 / 字段名。
-keep class com.sunset.forecast.MainActivity { *; }

# 页面通过 addJavascriptInterface("AndroidTheme") 按名字调用桥接方法，
# 方法名必须保留，否则 JS 侧调用会失效
-keepclassmembers class * {
    @android.webkit.JavascriptInterface <methods>;
}

# 允许修改访问修饰符，提升优化与混淆强度
-allowaccessmodification

# 彻底移除源码行号、源文件等调试信息，避免反编译时定位源码
-renamesourcefileattribute SourceFile

# 忽略第三方/平台缺失类告警（本工程仅依赖 android.* 与 javax.crypto）
-dontwarn **
-dontnote **

# ============================================================
#  通知 / 后台调度：手工引入的 AndroidX 预编译库
#  （无 Gradle、无 manifest merger，库清单组件与 proguard 规则都是手工补的）
# ============================================================
-keepattributes *Annotation*

# 预编译 AndroidX 一律保留（不裁剪、不混淆）：
# 这些类会被清单、Room（Class.forName 反射 WorkDatabase_Impl）、
# androidx.startup 初始化器、WorkFactory 反射实例化 Worker 等按名引用，
# 无法在本工程内静态验证，故整体保留，把运行时缺类风险降到最低。
-keep class androidx.** { *; }
-keep class com.google.common.util.concurrent.** { *; }

# WorkManager 反射实例化 Worker，需要的构造签名
-keep class * extends androidx.work.Worker { *; }
-keep class * extends androidx.work.InputMerger { *; }
-keep class androidx.work.WorkerParameters { *; }

# 本工程自己的清单组件与无界面刷新 Worker（同样按类名反射/声明）
-keep class com.sunset.forecast.RemindWorker { *; }
-keep class com.sunset.forecast.RemindWorker$Done { *; }
-keep class com.sunset.forecast.RemindReceiver { *; }
-keep class com.sunset.forecast.BootReceiver { *; }
-keep class com.sunset.forecast.AndroidBridge { *; }
